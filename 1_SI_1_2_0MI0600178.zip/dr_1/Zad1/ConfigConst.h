//
// Created by MILEN_PC on 3/22/2023.
//

#ifndef PRACTUCUMSEM2_CONFIGCONST_H
#define PRACTUCUMSEM2_CONFIGCONST_H

const int ROW_COUNT = 50;
const int COLUMN_COUNT = 10;
const int VALUE_LENGTH = 20;

enum class Alignment{
    LEFT, RIGHT, CENTER
};

#endif //PRACTUCUMSEM2_CONFIGCONST_H

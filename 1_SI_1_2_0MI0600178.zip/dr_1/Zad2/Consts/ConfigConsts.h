//
// Created by MILEN_PC on 3/31/2023.
//

#ifndef PRACTUCUMSEM2_CONFIGCONSTS_H
#define PRACTUCUMSEM2_CONFIGCONSTS_H

namespace Consts{
    const unsigned FILE_NAME = 64;
    const unsigned FILE_CONTENT = 512;
}

#endif //PRACTUCUMSEM2_CONFIGCONSTS_H

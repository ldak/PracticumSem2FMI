
#include "Menu/Menu.h"


int main() {
    Menu::startProgram("set.dat");

    return 0;
}
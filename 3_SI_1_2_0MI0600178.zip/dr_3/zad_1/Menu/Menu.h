//
// Created by MILEN_PC on 23.5.2023 г..
//

#ifndef PRACTUCUMSEM2_MENU_H
#define PRACTUCUMSEM2_MENU_H
#include "../Utils/MyString.h"
#include "../Sets/Set.h"
#include "../Sets/SetLoader.h"

namespace Menu{
    void startProgram(const MyString& fileName);
}


#endif //PRACTUCUMSEM2_MENU_H
